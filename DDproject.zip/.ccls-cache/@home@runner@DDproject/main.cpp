// #include <iostream>
// #include <fstream>
// #include <string>
// using namespace std;

// int main() {
//     // Open the file
//     ifstream inputFile("circuit.circ");

//     // Check if the file is opened successfully
//     if (!inputFile.is_open()) {
//         cout << "Error opening the file." << endl;
//         return 1;
//     }

//     string line;
//     // Read and output each line of the file
//     while (getline(inputFile, line)) {
//         cout << line << endl;
//     }

//     // Close the file
//     inputFile.close();

//     return 0;
// }

// #include <iostream>
// #include <fstream>
// #include <sstream>
// #include <string>
// #include <vector>
// #include <unordered_map>
// #include <functional>

// using namespace std;

// enum class GateType { AND, OR, NAND, NOT, XOR, NOR };


// struct GateInfo {
//     GateType type;
//     int numInputs;
//     string evaluate;
//     int delay;
// };


// class GateLibrary {
// private:
//     unordered_map<string, GateInfo> gates;

// public:

//     void addGate(const string& name, GateType type, int numInputs, string evaluate, int delay) {
//         gates[name] = {type, numInputs, evaluate, delay};
//     }


//     const GateInfo& getGate(const string& name) const {
//         return gates.at(name);
//     }


//     bool containsGate(const string& name) const {
//         return gates.find(name) != gates.end();
//     }


//     void printGates() const {
//     cout << "Gate Library:" << endl;
//     for (const auto& entry : gates) 
//     {
//         const GateInfo& gate = entry.second;
//         cout << "Gate: " << entry.first << endl;
//         cout << "Type: " << static_cast<int>(gate.type) << endl;
//         cout << "Num Inputs: " << gate.numInputs << endl;
//         cout << "Expression: " << gate.evaluate << endl;
//         cout << "Delay: " << gate.delay << endl;
//         cout << endl;
//     }
//   }
// };


// void loadGateLibrary(const string& filename, GateLibrary& gateLibrary) {
//     ifstream file(filename);
//     if (file.is_open()) {
//         string line;
//         while (getline(file, line)) {
//             stringstream ss(line);
//             string gateName, numInputsStr, expression, delayStr;
//             getline(ss, gateName, ',');
//             getline(ss, numInputsStr, ',');
//             getline(ss, expression, ',');
//             getline(ss, delayStr);
//             int numInputs = stoi(numInputsStr);
//             int delay = stoi(delayStr);
//             GateType type;
//             if (gateName == "AND") {
//                 type = GateType::AND;
//             } else if (gateName == "OR") {
//                 type = GateType::OR;
//             } else if (gateName == "NAND") {
//                 type = GateType::NAND;
//             } else if (gateName == "NOT") {
//                 type = GateType::NOT;
//             } else if (gateName == "XOR") {
//                 type = GateType::XOR;
//             } else if (gateName == "NOR") {
//                 type = GateType::NOR;
//             } else {
//                 cerr << "Invalid gate name: " << gateName << endl;
//                 continue;
//             }
//             //cout << expression << endl;
//             gateLibrary.addGate(gateName, type, numInputs, expression, delay);
//         }
//         file.close();
//     } else {
//         cerr << "Unable to open library file: " << filename << endl;
//     }
// }

// int main() {
//     GateLibrary gateLibrary;

//     loadGateLibrary("library.lib", gateLibrary);
//   gateLibrary.printGates();

//     return 0;
// }

// #include <iostream>
// #include <fstream>
// #include <string>
// #include <vector>

// using namespace std;

// struct Component {
//     string name;
//     string gateType;
//     string outputWire;
//     vector<string> inputs;
// };

// int main() {
//     ifstream inputFile("circuit.circ");
//     if (!inputFile.is_open()) {
//         cerr << "Failed to open file INPUTS\n";
//         return 1;
//     }

//     vector<string> inputs;
//     vector<Component> components;

//     string line;
//     while (getline(inputFile, line)) {
//         if (line == "COMPONENTS")
//             break;
//         inputs.push_back(line);
//     }

//     while (getline(inputFile, line)) {
//         Component comp;
//         if (line.empty())
//             continue;
//         if (line.find(',') == string::npos)
//             break;

//         size_t pos = 0;
//         pos = line.find(',');
//         comp.name = line.substr(0, pos);
//         line.erase(0, pos + 1);

//         pos = line.find(',');
//         comp.gateType = line.substr(0, pos);
//         line.erase(0, pos + 1);

//         pos = line.find(',');
//         comp.outputWire = line.substr(0, pos);
//         line.erase(0, pos + 1);

//         while ((pos = line.find(',')) != string::npos) {
//             string input = line.substr(0, pos);
//             comp.inputs.push_back(input);
//             line.erase(0, pos + 1);
//         }
//         comp.inputs.push_back(line);
//         components.push_back(comp);
//     }

//     cout << "Inputs:\n";
//     for (const auto& input : inputs) {
//         cout << input << endl;
//     }

//     cout << "\nComponents:\n";
//     for (const auto& comp : components) {
//         cout << "Name: " << comp.name << ", Gate Type: " << comp.gateType << ", Output Wire: " << comp.outputWire << ", Inputs:";
//         for (const auto& input : comp.inputs) {
//             cout << " " << input;
//         }
//         cout << endl;
//     }

//     inputFile.close();
//     return 0;
// }




#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <functional>

using namespace std;

enum class GateType { AND, OR, NAND, NOT, XOR, NOR };

struct GateInfo {
    GateType type;
    int numInputs;
    string evaluate;
    int delay;
};

class GateLibrary {
private:
    unordered_map<string, GateInfo> gates;

public:
    void addGate(const string& name, GateType type, int numInputs, string evaluate, int delay) {
        gates[name] = {type, numInputs, evaluate, delay};
    }

    const GateInfo& getGate(const string& name) const {
        return gates.at(name);
    }

    bool containsGate(const string& name) const {
        return gates.find(name) != gates.end();
    }

    void printGates() const {
        cout << "Gate Library:" << endl;
        for (const auto& entry : gates) {
            const GateInfo& gate = entry.second;
            cout << "Gate: " << entry.first << endl;
            cout << "Type: " << static_cast<int>(gate.type) << endl;
            cout << "Num Inputs: " << gate.numInputs << endl;
            cout << "Expression: " << gate.evaluate << endl;
            cout << "Delay: " << gate.delay << endl;
            cout << endl;
        }
    }
};

void loadGateLibrary(const string& filename, GateLibrary& gateLibrary) {
    ifstream file(filename);
    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string gateName, numInputsStr, expression, delayStr;
            getline(ss, gateName, ',');
            getline(ss, numInputsStr, ',');
            getline(ss, expression, ',');
            getline(ss, delayStr);
            int numInputs = stoi(numInputsStr);
            int delay = stoi(delayStr);
            GateType type;
            if (gateName == "AND") {
                type = GateType::AND;
            } else if (gateName == "OR") {
                type = GateType::OR;
            } else if (gateName == "NAND") {
                type = GateType::NAND;
            } else if (gateName == "NOT") {
                type = GateType::NOT;
            } else if (gateName == "XOR") {
                type = GateType::XOR;
            } else if (gateName == "NOR") {
                type = GateType::NOR;
            } else {
                cerr << "Invalid gate name: " << gateName << endl;
                continue;
            }
            gateLibrary.addGate(gateName, type, numInputs, expression, delay);
        }
        file.close();
    } else {
        cerr << "Unable to open library file: " << filename << endl;
    }
}

class Circuit {
public:
    unordered_map<string, bool> inputs;
    unordered_map<string, bool> outputs;
    unordered_map<string, string> wires; // Mapping wire names to gate output names
    GateLibrary& gateLibrary;


    Circuit(GateLibrary& lib) : gateLibrary(lib) {}

    void setInput(const string& inputName, bool value) {
        inputs[inputName] = value;
    }

    bool getOutput(const string& outputName) const {
        return outputs.at(outputName);
    }

    void simulate() {
        for (const auto& entry : wires) {
            string wireName = entry.first;
            string gateName = entry.second;
            const GateInfo& gate = gateLibrary.getGate(gateName);

            if (gate.type == GateType::NOT) {
                outputs[wireName] = !inputs[gate.evaluate];
            } else if (gate.type == GateType::AND) {
                bool result = true;
                stringstream ss(gate.evaluate);
                string inputName;
                while (getline(ss, inputName, ',')) {
                    result = result && inputs[inputName];
                }
                outputs[wireName] = result;
            } else if (gate.type == GateType::OR) {
                bool result = false;
                stringstream ss(gate.evaluate);
                string inputName;
                while (getline(ss, inputName, ',')) {
                    result = result || inputs[inputName];
                }
                outputs[wireName] = result;
            } else if (gate.type == GateType::NAND) {
                bool result = true;
                stringstream ss(gate.evaluate);
                string inputName;
                while (getline(ss, inputName, ',')) {
                    result = result && inputs[inputName];
                }
                outputs[wireName] = !result;
            } else {
                cerr << "Unsupported gate type." << endl;
            }
        }
    }

    void connectWire(const string& wireName, const string& outputName) {
        wires[wireName] = outputName;
    }
};

void loadCircuit(const string& filename, Circuit& circuit) {
    ifstream file(filename);
    if (file.is_open()) {
        string line;
        string section;
        while (getline(file, line)) {
            if (line == "INPUTS" || line == "COMPONENTS") {
                section = line;
                continue;
            }

            stringstream ss(line);
            string gateName, gateType, output, input1, input2;
            getline(ss, gateName, ',');
            getline(ss, gateType, ',');
            getline(ss, output, ',');
            if (gateType == "NOT") {
                getline(ss, input1);
                circuit.connectWire(output, input1);
            } else {
                getline(ss, input1, ',');
                getline(ss, input2);
                circuit.connectWire(output, gateName);
                circuit.setInput(input1, false); // Assume inputs are initially false
                circuit.setInput(input2, false);
            }
        }
        file.close();
    } else {
        cerr << "Unable to open circuit file: " << filename << endl;
    }
}

int main() {
    GateLibrary gateLibrary;
    loadGateLibrary("library.lib", gateLibrary);

    Circuit circuit(gateLibrary);
    loadCircuit("circuit.circ", circuit);

    // Simulate the circuit
    circuit.simulate();

    // Output the results
    for (const auto& entry : circuit.outputs) {
        cout << "Output " << entry.first << ": " << entry.second << endl;
    }

    return 0;
}
